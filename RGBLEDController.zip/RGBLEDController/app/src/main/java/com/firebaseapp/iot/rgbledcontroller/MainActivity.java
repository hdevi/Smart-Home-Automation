package com.firebaseapp.iot.rgbledcontroller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.things.pio.Gpio;
import com.google.android.things.pio.PeripheralManagerService;
import com.google.android.things.pio.Pwm;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();


    //Constants for Raspberry Ports
    private final String PIN_LED = "BCM6";
    private final String PIN_PWMB = "PWM1";
    private final String PIN_PWMR = "PWM0";

    private FirebaseDatabase mDatabase;
    DatabaseReference mRef_Blue = null;
    DatabaseReference mRef_Red = null;
    DatabaseReference mRef_Green = null;
    //Gpio and Pwm references
    Gpio mGPIO;
    Pwm mPWMB;
    Pwm mPWMR;
    TextView mTextblue;
    TextView mTextred;
    TextView mTextgreen;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "On create");

        mTextblue = (TextView) findViewById(R.id.textBlue);
        mTextred = (TextView) findViewById(R.id.textRed);
        mTextgreen = (TextView) findViewById(R.id.textGreen);

        //Creating Object for Peripheral Manager so the Hardware peripherals can be connected to android App
        final PeripheralManagerService manager = new PeripheralManagerService();

        //To obtain the PWM Port list for Raspberry Pi
        List<String> portList = manager.getPwmList();
        if (portList.isEmpty()) {
            Log.i(TAG, "No PWM port available on this device.");
        } else {
            Log.i(TAG, "List of available ports: " + portList);
        }
        try {
            //Instructs the Peripheral manager to open the Ports
            mPWMB = manager.openPwm(PIN_PWMB);
            mPWMR = manager.openPwm(PIN_PWMR);
            mGPIO = manager.openGpio(PIN_LED);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //init_pins(manager);
        mDatabase = FirebaseDatabase.getInstance();
        mRef_Blue = mDatabase.getReference().child("Bbrightness");
        //Receives the Respective Data Changes from the Firebase
        mRef_Blue.addValueEventListener(new ValueEventListener() {

            //This method is called to obtain the recent value of the child element in the database
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Double duty;
                mTextblue.setText("Blue: " + dataSnapshot.getValue());
                Log.d(TAG, " " + dataSnapshot.getValue());
                //Typecasting the String value obtained from firebase to Double
                Double Ton = Double.parseDouble((dataSnapshot.getValue().toString()));
                duty = Ton;
                Log.d(TAG, " Duty: " + duty);
                try {

                    mPWMB.setPwmFrequencyHz(120);
                    mPWMB.setPwmDutyCycle(duty);


                    mPWMB.setEnabled(true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mRef_Red = mDatabase.getReference().child("Rbrightness");
        mRef_Red.addValueEventListener(new ValueEventListener() {
            //This method is called to obtain the recent value of the child element in the database
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Double duty;
                mTextred.setText("Red: " + dataSnapshot.getValue());
                Log.d(TAG, "RED:  " + dataSnapshot.getValue());
                //Typecasting the String value obtained from firebase to Double
                Double Ton = Double.parseDouble((dataSnapshot.getValue().toString()));
                duty = Ton;
                Log.d(TAG, " Duty: " + duty);
                try {

                    mPWMR.setPwmFrequencyHz(120);
                    mPWMR.setPwmDutyCycle(duty);


                    mPWMR.setEnabled(true);
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mRef_Green = mDatabase.getReference().child("Gbrightness");
        mRef_Green.addValueEventListener(new ValueEventListener() {
            //This method is called to obtain the recent value of the child element in the database
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mTextgreen.setText("Green: " + dataSnapshot.getValue());
                Log.d(TAG, "GREEN:  " + dataSnapshot.getValue());

                try {
                    mGPIO.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
                    Log.d(TAG, "Direction set");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Long value = (Long) dataSnapshot.getValue();
                if (value == 1)
                    try {
                        Log.d(TAG, "Inside IF");
                        mGPIO.setValue(true);
                    } catch (IOException e) {
                        Log.d(TAG, "after IF");
                        e.printStackTrace();
                    }
                else
                    try {
                        Log.d(TAG, "Inside else");
                        mGPIO.setValue(false);
                    } catch (IOException e) {
                        Log.d(TAG, "after else");
                        e.printStackTrace();
                    }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mPWMB != null) {
            try {
                //closes Pwm port for Blue LED so that it can be used again
                mPWMB.close();
                mPWMB = null;
            } catch (IOException e) {
                Log.w(TAG, "Unable to close PWM", e);
            }
        }

        if (mPWMR != null) {
            try {
                //closes Pwm port for Red LED so that it can be used again
                mPWMR.close();
                mPWMR = null;
            } catch (IOException e) {
                Log.w(TAG, "Unable to close PWM", e);
            }
        }


    }
}
