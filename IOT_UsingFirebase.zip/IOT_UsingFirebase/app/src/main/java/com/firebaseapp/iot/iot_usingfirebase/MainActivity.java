package com.firebaseapp.iot.iot_usingfirebase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener{

    private  static final String TAG = MainActivity.class.getSimpleName();

    //references to Seekbar and Switch widgets
    private SeekBar mBlue;
    private SeekBar mRed;
    private Switch mGreen;

    //TextView to display Realtime values of seekers and switch
    private TextView mText1;
    private TextView mText2;
    private TextView mText3;

    //Reference to Firebase Database
    private FirebaseDatabase mDatabase;
    DatabaseReference mRef_Blue = null;
    DatabaseReference mRef_Red = null;
    DatabaseReference mRef_Green = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Gets a Firebase database instance
        mDatabase = FirebaseDatabase.getInstance();
        mRef_Blue = mDatabase.getReference();
        mRef_Red = mDatabase.getReference();
        mRef_Green = mDatabase.getReference();


        mBlue = (SeekBar) findViewById(R.id.blueseekBar1);
        mBlue.setMax(100);
        mBlue.setProgress(0);
        mBlue.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener(){

                    //Method to update the value of "Bbrightness" child element of database
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        mText1.setText("Blue : "+String.valueOf(progress));
                        mRef_Blue.child("Bbrightness").setValue(String.valueOf(progress));

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                });
        mRed = (SeekBar) findViewById(R.id.redseekBar2);
        mRed.setMax(100);
        mRed.setProgress(0);
        mRed.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener(){

                    //Method to update the value of "Rbrightness" child element of database
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        mText2.setText("Red : "+String.valueOf(progress));
                        mRef_Red.child("Rbrightness").setValue(String.valueOf(progress));
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                });


        mGreen = (Switch) findViewById(R.id.greenswitch1);
        mGreen.setOnCheckedChangeListener(this);

        mText1 = (TextView) findViewById(R.id.text1);
        mText2 = (TextView) findViewById(R.id.text2);
        mText3 = (TextView) findViewById(R.id.text3);
    }


    //Method to check state of Switch
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        if(isChecked)
        {
            mText3.setText("Green is lighted");
            mRef_Green.child("Gbrightness").setValue(1);
        }else{
            mText3.setText("Green is unlighted");
            mRef_Green.child("Gbrightness").setValue(0);
        }

    }
}
